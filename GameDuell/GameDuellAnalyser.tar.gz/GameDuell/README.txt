make script executable
chmod +x start.sh

make writable the tmp folder in the same folder
chmod -R 777  tmp 

start the script start.sh
example: ./start.sh 


and follow the instructions in the console.
